docker build -f ./Dockerfile -t uipath/secret-copier:0.1 .
